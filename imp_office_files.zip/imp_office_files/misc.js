function printVal() {
    var obj = [{
        "name": "a",
        "value": 1
    },
    {
        "name": "b",
        "value": 2
    },
    {
        "name": "c",
        "value": 3
    }];
    let filterObj = [];
    obj.forEach((e) => {
        if(e.value >= 2){
            filterObj.push(e.name);
        }
    });

    return filterObj;
}
function findRepeat(){
    var string = 'siith';
    var splitStr = string.split('');
    splitStr.reduce((a, b) => {
        let index = a.findIndex(i => b === i);
        if(index > -1){
            return a;
        };
    });
}

export class shareService{
    public sharedData = 1;
}

export class componentOne{
    constructor(private service: shareService) { }

    public event(){
        this.service.sharedData = 5;
    }
}

export class componentTwo implements onInit{
    constructor(private service: shareService) { }

    public get getData(){
        this.service.sharedData;
    }

    ngOnInit(){
        console.log(this.getData);
    }
}

function shuffleNumber(){
    var arr = [];
    while(arr.length < 10){
        var r = Math.floor(Math.random() * 10) + 1;
        if(arr.indexOf(r) === -1) arr.push(r);
    }
}
