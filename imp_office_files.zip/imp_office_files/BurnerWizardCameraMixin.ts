// Libraries
import { Component, namespace } from 'nuxt-property-decorator';
import axios from 'axios';
import EventBus from '@/shared/event-bus';
// View Models
import { IBurnerLogUploadImageApiDto, IBurnerLogImageViewModel, IBurnerLogsViewModel } from '@/view-models/ember';
// Enums
import { CameraProperty } from '@/enums';
// Components
import BaseComponent from '@/shared/BaseComponent';
// Stores
import * as burnerStatus from '@/store/burner-status';
import * as burnerCamera from '@/store/burner-camera';
import { IDownloadImageRequest } from '@/store';
import { IImageCache } from '@/store/types/burner-camera';
const BurnerStatusStore = namespace(burnerStatus.name);
const BurnerCameraStore = namespace(burnerCamera.name);

@Component
export default class BurnerWizardCameraMixin extends BaseComponent {
  // VUEX
  @BurnerStatusStore.Action(burnerStatus.types.actions.UPLOAD_IMAGE)
  public uploadImage: (burnerKey: string) => Promise<IBurnerLogUploadImageApiDto>;
  @BurnerStatusStore.Action(burnerStatus.types.actions.DOWNLOAD_IMAGE)
  public downloadImage: (request: IDownloadImageRequest) => Promise<string>;
  @BurnerStatusStore.Action(burnerStatus.types.actions.UPLOAD_IMAGE_FOR_ASSET_LOG)
  public uploadImageForAssetLog: (key: string) => Promise<IBurnerLogUploadImageApiDto>;
  @BurnerStatusStore.Action(burnerStatus.types.actions.DOWNLOAD_IMAGE_FOR_ASSET_LOG)
  public downloadImageForAssetLog: (request: IDownloadImageRequest) => Promise<string>;
  @BurnerCameraStore.Mutation(burnerCamera.types.mutations.SET_GALLERY_THUMBNAIL)
  public setGalleryThumbnail: (data: IBurnerLogImageViewModel) => void;
  @BurnerCameraStore.Mutation(burnerCamera.types.mutations.SET_BURNER_KEY)
  public setBurnerKey: (key: string) => void;
  @BurnerCameraStore.Mutation(burnerCamera.types.mutations.SET_ASSET_LOG_FLAG)
  public setAssetLogFlag: (flag: boolean) => void;
  @BurnerCameraStore.Mutation(burnerCamera.types.mutations.UPDATE_IMAGE_SOURCE)
  public updateImageSource: (data: IImageCache) => void;
  @BurnerStatusStore.State
  public activeAssetKey: string;
  @BurnerCameraStore.State
  public burnerKey: string;
  @BurnerCameraStore.State
  public assetLogFlag: boolean;
  @BurnerCameraStore.State
  public galleryThumbnail:Array<IBurnerLogImageViewModel>;

  // Properties
  public show: boolean = false;
  public videoWidth: number = 640;
  public videoHeight: number = 480;
  public httpInstance = axios.create();
  public video: HTMLVideoElement;
  public isVideo: boolean;
  public thumbNailIcon:string = '';
  public imageVideoSource: string;

  public get gallaryThumbnailImageSize(): number {
    return this.galleryThumbnail.reduce((a: number, b) => a + (b.isSelected ? this.dataURLtoBlob(b.thumbnail) : 0), 0);
  }

  // Helper Methods
  // Method to create the thumbNail icons.
  public thumbnailify(base64Image: string, targetSize: number): string {
    const image = new Image();
    const that = this;
    image.onload = function() {
      const width = image.width;
      const height = image.height;
      const canvas = document.createElement(CameraProperty.Canvas);
      const ctx = canvas.getContext('2d');
      canvas.width = canvas.height = targetSize;
      ctx.drawImage(
        image, width > height ? (width - height) / 2 : 0, height > width ? (height - width) / 2 : 0,
        width > height ? height : width, width > height ? height : width, 0, 0, targetSize, targetSize
      );
      that.thumbNailIcon = canvas.toDataURL();
      that.onPreviewSuccess();
    };
    image.src = base64Image;
    return '';
  };

  public dataURLtoBlob(dataURL) {
    const binary = atob(dataURL.split(',')[1]);
    const array = [];
    for (let i = 0; i < binary.length; i++) {
        array.push(binary.charCodeAt(i));
    }
    return new Blob([new Uint8Array(array)], { type: 'image/png' }).size;
  }

  // Upload the photo on clicking green color icon(sucess) in preview screen.
  public onPreviewSuccess(): void {
    const imageData: IBurnerLogImageViewModel = Object.assign({});
    const entityKey: string = this.burnerKey ? this.burnerKey : this.activeAssetKey;
    // api call to fetch the pre-signed url.
    if (this.assetLogFlag === true) {
      this.uploadImageForAssetLog(entityKey)
        .then((result:IBurnerLogUploadImageApiDto) => {
          // Uploading the image with the pre-signed url.
          imageData.imageKey = result.imageKey;
          imageData.thumbnail = this.thumbNailIcon;
          imageData.title = '';
          imageData.isVideo = this.isVideo;
          imageData.imageSource = this.imageVideoSource;
          this.httpInstance.put(result.preSignedUrl, this.imageVideoSource).then(() => {
            this.updateLoading(false);
            imageData.isSelected = true;
            this.setGalleryThumbnail(imageData);
        }, (error) => {
            this.updateLoading(false);
            this.catch(error);
          });
        })
        .catch(this.catch);
    } else if (this.assetLogFlag === false) {
      this.uploadImage(this.burnerKey)
        .then((result:IBurnerLogUploadImageApiDto) => {
          // Uploading the image with the pre-signed url.
          imageData.imageKey = result.imageKey;
          imageData.thumbnail = this.thumbNailIcon;
          imageData.title = '';
          imageData.isVideo = this.isVideo;
          imageData.imageSource = this.imageVideoSource;
          this.httpInstance.put(result.preSignedUrl, this.imageVideoSource).then(() => {
            this.updateLoading(false);
            imageData.isSelected = true;
            this.setGalleryThumbnail(imageData);
          }, (error) => {
            this.updateLoading(false);
            this.catch(error);
          });
        })
        .catch(this.catch);
    }
  }

  // Start camera for video and image
  public startCamera(event: Event) {
    if ((<HTMLInputElement>event.target).files.length === 0) {
      return;
    }
    this.updateLoading(true);
    this.isVideo = (<HTMLInputElement>event.target).name !== CameraProperty.Image;
    if ((<HTMLInputElement>event.target).name === CameraProperty.Image) {
      this.base64ForMedia(event);
    } else {
      this.validateVideo(event);
    }
  }

  // Base64 string for video and image
  public base64ForMedia(event: Event, isVideo:boolean = false) {
    const file:File = (<HTMLInputElement>event.target).files[0];
    const reader:FileReader = new FileReader();
    let data:any;
    reader.addEventListener('load', () => {
      // convert file to base64 string
      data = reader.result;
      if (isVideo) {
        this.imageVideoSource = data.replace('data:video/quicktime;', 'data:video/mp4;');
        this.base64ThumbForVideo(event);
      } else {
        const img: any = new Image();
        img.src = reader.result;
        img.onload = () => {
          const elem = document.createElement('canvas');
          elem.width = img.width;
          elem.height = img.height;
          const ctx = elem.getContext('2d');
          ctx.drawImage(img, 0, 0, elem.width, elem.height);
          const data = elem.toDataURL('image/jpeg', 0.3);
          this.imageVideoSource = data;
          this.thumbnailify(data, 60);
        };
      }
    }, false);
    if (file) {
      reader.readAsDataURL(file);
    }
  }
  // Validating video duration
  public validateVideo(event: Event) {
    const file:File = (<HTMLInputElement>event.target).files[0];
    const video: HTMLVideoElement = document.createElement(CameraProperty.Video) as HTMLVideoElement;
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      window.URL.revokeObjectURL(video.src);
      const duration = this.flagValue('videoLimitInSeconds', 21);
      if (video.duration > duration) {
        alert(this.$t('camera.videoUploadLimit').toString() + duration + this.$t('camera.seconds').toString());
        this.updateLoading(false);
      } else {
        this.base64ForMedia(event, true);
      }
    };
    video.src = URL.createObjectURL(file);
  }

  // Creating thumbnail for video
  public base64ThumbForVideo(event: Event) {
    const file:File = (<HTMLInputElement>event.target).files[0];
    const fileReader:FileReader = new FileReader();
    fileReader.onload = () => {
      const blob = new Blob([fileReader.result], { type: file.type });
      const url = URL.createObjectURL(blob);
      this.video = document.createElement(CameraProperty.Video) as HTMLVideoElement;
      const timeupdate = () => {
        if (this.snapImage()) {
          this.video.removeEventListener('timeupdate', timeupdate);
          this.video.pause();
        }
      };
      this.video.addEventListener('loadeddata', () => {
        if (this.snapImage()) {
          this.video.removeEventListener('timeupdate', timeupdate);
        }
      });
      this.video.addEventListener('timeupdate', timeupdate);
      this.video.preload = 'metadata';
      this.video.src = url;
      // Load video in Safari / IE11
      this.video.muted = true;
      this.video.setAttribute(CameraProperty.Playsinline, '');
      this.video.play();
    };
    fileReader.readAsArrayBuffer(file);
  }

  // Take snap from video
  public snapImage() {
    const canvas = document.createElement(CameraProperty.Canvas);
    canvas.width = this.video.videoWidth;
    canvas.height = this.video.videoHeight;
    canvas.getContext('2d').drawImage(this.video, 0, 0, canvas.width, canvas.height);
    const image = canvas.toDataURL();
    const success = image.length > 100000;
    if (success) {
      this.thumbnailify(image, 60);
    }
    return success;
  };

  public getPreSignedUrlfordownload(imageKey: string, fromLog: boolean = false, log: IBurnerLogsViewModel = null) {
    const entityKey: string = (fromLog ? log.burnerKey : this.burnerKey) ? (fromLog ? log.burnerKey : this.burnerKey) : this.activeAssetKey;
    this.updateLoading(true);
    if (this.assetLogFlag === true) {
      this.downloadImageForAssetLog({ key: entityKey, imagekey: fromLog ? log.logImages[0].imageKey : imageKey })
        .then((preSignedUrl: string) => {
          // Downloading the image with the pre-signed url.
          this.httpInstance.get(preSignedUrl).then((result) => {
            this.updateLoading(false);
            // To have the local image cache collection.
            this.updateImageSource({ key: fromLog ? log.logImages[0].imageKey : imageKey, source: result.data });
            if (fromLog) {
              EventBus.$emit('image-viewer-modal::show', log);
            }
          }, (error) => {
            this.updateLoading(false);
            this.catch(error);
          }).catch(this.catch);
        }).catch(this.catch);
    } else if (this.assetLogFlag === false) {
      this.downloadImage({ key: fromLog ? log.burnerKey : this.burnerKey, imagekey: fromLog ? log.logImages[0].imageKey : imageKey })
        .then((preSignedUrl: string) => {
          // Downloading the image with the pre-signed url.
          this.httpInstance.get(preSignedUrl).then((result) => {
            this.updateLoading(false);
            // To have the local image cache collection.
            this.updateImageSource({ key: fromLog ? log.logImages[0].imageKey : imageKey, source: result.data });
            if (fromLog) {
              EventBus.$emit('image-viewer-modal::show', log);
            }
          }, (error) => {
            this.updateLoading(false);
            this.catch(error);
          }).catch(this.catch);
        }).catch(this.catch);
    }
  }
}
